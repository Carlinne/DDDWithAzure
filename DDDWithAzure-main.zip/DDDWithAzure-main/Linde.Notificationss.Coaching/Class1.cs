﻿namespace Linde.Notificationss.Coaching
{
    public class Class1
    {

    }
}