﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Linde.Domain.Coaching.Views
{
    public class VwEmpleado
    {
        public string? NameComplete { get; set; }
        public decimal? NoEmPloyee { get; set; }
        public string? Email { get; set; }
        public string? User { get; set; }
        public decimal? CIA { get; set; }
        public string? Bu { get; set; }
        public decimal? NoAutorizationEmployee { get; set; }
        public string? CodeCountry { get; set; }
        public string? NoSupervisor { get; set; }
        public string? Supervisor { get; set; }
        public string? Name { get; set; }
        public string? FirstLastName { get; set; }
        public string? SecondLastName { get; set; }

    }
}
