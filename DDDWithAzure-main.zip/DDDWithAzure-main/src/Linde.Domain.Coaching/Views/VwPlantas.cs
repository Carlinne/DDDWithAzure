﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Linde.Domain.Coaching.Views
{
    public class VwPlantas
    {
        public double? NumSucursal { get; set; }
        public string? Sucursal { get; set; }
        public string? Pais { get; set; }
        public string? Division { get; set; }
        public string? Estado { get; set; }
        public string? Ciudad { get; set; }
        public string? Municipio { get; set; }
    }
}