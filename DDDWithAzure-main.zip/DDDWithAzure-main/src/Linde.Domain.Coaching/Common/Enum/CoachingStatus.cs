﻿namespace Linde.Domain.Coaching.Common.Enum;

public enum CoachingStatus
{
    Closed = 1,
    InProgress = 2,
    Opened = 3,
}
