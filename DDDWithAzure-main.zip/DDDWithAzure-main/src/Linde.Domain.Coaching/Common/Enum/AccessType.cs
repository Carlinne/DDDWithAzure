﻿namespace Linde.Domain.Coaching.Common.Enum;

public enum AccessType
{
    Mobile = 1,
    WebApp = 2,
    Booth = 3,
}