﻿namespace Linde.Domain.Coaching.Common.Enum;

public enum TypeUser
{
    Supervisor = 1,
    Normal = 2,
    Administrator = 3,
}