﻿namespace Linde.Domain.Coaching.Common;

public interface IAggregateRoot
{
}
