﻿namespace Linde.Api.Coaching.Common.Http;

public static class HttpContextItemKeys
{
    public const string Errors = "errors";
}
