﻿namespace Linde.Core.Coaching.Common.Models.Catalogs.Country;

public record CountryDto(
    Guid Id,
    string Name,
    string Code);