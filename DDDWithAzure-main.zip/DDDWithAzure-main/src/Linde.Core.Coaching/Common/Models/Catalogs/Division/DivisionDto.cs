﻿
namespace Linde.Core.Coaching.Common.Models.Catalog.Division;

public record DivisionDto
    (
        Guid Id,
        string Name
    );