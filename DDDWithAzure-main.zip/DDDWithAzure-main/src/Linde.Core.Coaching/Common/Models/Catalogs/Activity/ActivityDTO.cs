﻿namespace Linde.Core.Coaching.Common.Models.Catalog.Activity;

public record ActivityDTO
(
    Guid Id,
    string Name,
    string Description
);
