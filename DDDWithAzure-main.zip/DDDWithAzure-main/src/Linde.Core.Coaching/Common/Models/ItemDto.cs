﻿namespace Linde.Core.Coaching.Common.Models;

public record ItemDto(
    Guid Id,
    string Name);
