﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Linde.Core.Coaching.Common.Models.Common
{
    public record UserAutocompleteDto(
    Guid Id,
    string Name);
}
