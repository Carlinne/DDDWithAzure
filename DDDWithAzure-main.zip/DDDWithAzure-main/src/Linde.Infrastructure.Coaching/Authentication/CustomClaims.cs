﻿namespace Linde.Infrastructure.Coaching.Authentication;

internal static class CustomClaims
{
    internal const string Permissions = "permissions";
}
