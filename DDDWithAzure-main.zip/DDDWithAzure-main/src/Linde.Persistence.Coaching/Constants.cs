﻿namespace Linde.Persistence.Coaching;

internal static class Constants
{
    internal const string Schema = "dbo";
    internal const string ConnectionStringName = "CoachingConnection";
}
